How to use the GUI:
Run the Main.java class in <SelfCheckoutSystem - Software/org/lsmr/SelfCheckoutSystem/Software>

Valid Denominations:
    -   Coin { 0.05, 0.1, 0.25, 1, 2 }
    -   Banknote { 5, 10, 20, 50, 100 }

Barcodes in DB:
    -   1234
    -   2341
    -   3412
    -   4123
    -   4321
    -   3214

PriceLookupCodes in DB:
    -   1234
    -   2341
    -   3412
    -   4123
    -   4321
    -   3214

Attendants in DB:
    -   1234
    -   4321

Cards in DB:
    Debit:
        -   Number: 123456 Pin:1234
        -   Number: 654321 Pin:1234
    Credit:
        -   Number: 123456 Pin:1234
        -   Number: 654321 Pin:1234  
    Gift:
        -   Number: 123456 Pin:1234
        -   Number: 654321 Pin:1234